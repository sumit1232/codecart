export default function App() { return <h1>AI Resume Analyzer</h1>; }
