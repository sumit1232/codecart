const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: AI Resume Analyzer'));
app.listen(5000);
