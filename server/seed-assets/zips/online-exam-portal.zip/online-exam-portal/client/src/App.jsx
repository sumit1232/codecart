export default function App() { return <h1>Online Exam Portal</h1>; }
