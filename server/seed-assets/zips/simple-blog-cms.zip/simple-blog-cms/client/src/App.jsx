export default function App() { return <h1>Blog CMS</h1>; }
