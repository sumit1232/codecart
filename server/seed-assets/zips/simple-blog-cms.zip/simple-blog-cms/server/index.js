const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Blog CMS'));
app.listen(5000);
