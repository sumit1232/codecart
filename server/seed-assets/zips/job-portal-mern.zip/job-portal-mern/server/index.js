const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Job Portal'));
app.listen(5000);
