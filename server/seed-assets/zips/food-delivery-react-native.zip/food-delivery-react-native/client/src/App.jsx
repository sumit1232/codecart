export default function App() { return <h1>Food Delivery App</h1>; }
