const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Food Delivery App'));
app.listen(5000);
