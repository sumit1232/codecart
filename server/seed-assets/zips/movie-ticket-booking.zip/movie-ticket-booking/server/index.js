const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Movie Ticket Booking'));
app.listen(5000);
