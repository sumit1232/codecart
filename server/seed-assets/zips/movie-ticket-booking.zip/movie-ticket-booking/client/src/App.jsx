export default function App() { return <h1>Movie Ticket Booking</h1>; }
