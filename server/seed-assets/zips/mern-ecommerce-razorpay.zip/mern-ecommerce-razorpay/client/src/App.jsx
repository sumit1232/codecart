export default function App() { return <h1>MERN E-commerce Store</h1>; }
