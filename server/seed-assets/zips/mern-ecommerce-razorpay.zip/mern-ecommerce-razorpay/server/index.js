const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: MERN E-commerce Store'));
app.listen(5000);
