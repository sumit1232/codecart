# Setup guide

See README.md in the project root.
