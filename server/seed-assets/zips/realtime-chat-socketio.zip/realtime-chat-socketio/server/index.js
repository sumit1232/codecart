const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Real-time Chat App'));
app.listen(5000);
