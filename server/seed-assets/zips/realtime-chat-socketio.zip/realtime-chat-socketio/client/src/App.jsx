export default function App() { return <h1>Real-time Chat App</h1>; }
