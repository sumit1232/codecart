export default function App() { return <h1>Crypto Tracker Dashboard</h1>; }
