const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Crypto Tracker Dashboard'));
app.listen(5000);
