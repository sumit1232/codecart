# Crypto Tracker Dashboard

Live prices, watchlist, portfolio charts

## Setup
1. `cd server && npm install && cp .env.example .env`
2. `cd client && npm install`
3. Start MongoDB, then `npm run dev` in both folders.

This is DEMO data for the CodeCart sample store.
