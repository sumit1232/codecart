export default function App() { return <h1>Student Result System</h1>; }
