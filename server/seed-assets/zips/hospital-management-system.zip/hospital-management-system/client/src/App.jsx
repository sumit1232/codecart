export default function App() { return <h1>Hospital Management System</h1>; }
