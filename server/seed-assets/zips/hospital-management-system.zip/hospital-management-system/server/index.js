const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: Hospital Management System'));
app.listen(5000);
