export default function App() { return <h1>2D Platformer Game</h1>; }
