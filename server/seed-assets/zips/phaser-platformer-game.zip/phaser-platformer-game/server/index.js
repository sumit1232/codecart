const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Demo project: 2D Platformer Game'));
app.listen(5000);
