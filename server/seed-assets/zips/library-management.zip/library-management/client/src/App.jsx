export default function App() { return <h1>Library Management</h1>; }
